/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "math.h"
#include <stdlib.h>
#include "adc.h"
#include "pmsm.h"
#include "delay.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
void OFFSET_Cur(void);
void SampleCur(void);
void SamplePos(void);
void CurLoop(void);
void Protect(void);
void PwmGen(void);
void SpdLoop(void);
void Ref_Get(void);
uint16_t test  = 0;
uint8_t canbuf[8];//ͨѶ��������
uint16_t canbuf_Rx[8]= {0,0,0,0,0,0,0,0};//ͨѶ����
uint8_t canbuf_Tx[8]= {0,0,0,0,0,0,0,0};
typedef struct {
	uint8_t OverTem : 1;//�����쳣
	uint8_t UnderVol : 1 ;//Ƿѹ
	uint8_t OverVol :	1;//��ѹ
	uint8_t CurOver  : 1;//����
	uint16_t rsd : 4;
}S3 ;
union u1
{	
	uint8_t Stop;
	S3 Status;
}	Flag;//���״̬����
uint16_t	TIM3CH1_CAPTURE_VAL=0;//����ģ��ָ��ռ�ձ�
uint16_t	TIM3CH1_CAPTURE_VAL2=0;
uint16_t TIM3CH1_CAPTURE_STA =0x80;
uint16_t TIM3CH1_COUNTER =0;
//CAN_HandleTypeDef hcan;
CAN_FilterTypeDef sFilterConfig;
CAN_TxHeaderTypeDef	TxHeader;      //����
CAN_RxHeaderTypeDef	RxHeader;      //����
int POS_Counter = 0; 
int HALL_Counter = 0; 
int ECounter = 0; 
int ECounter_Pre = 0;
int Count_RF = 0;

int s_count = 0;
int s_flag = 0;
int err =0;
int spd_f[10] ={0,0,0,0,0,0,0,0,0,0,};
float spd_c =0;
float test1 =0;
#define DISP0 0xFC // 11111100
#define DISP1 0x60 // 01100000
#define DISP2 0xDA // 11011010
#define DISP3 0xF2 // 11110010
#define DISP4 0x66 // 01100110
#define DISP5 0xB6 // 10110110
#define DISP6 0xBE // 10111110
#define DISP7 0xE0 // 11100000
#define DISP8 0xFE // 11111110
#define DISP9 0xF6 // 11110110

#define	LED 		PCout(15)  		//ָʾ���ź�
#define	LED_H 		PAout(12)  		//����ָʾ��H 
#define	LED_M 		PAout(11)  		//����ָʾ��M
#define	LED_L 		PAout(10)  		//����ָʾ��L
#define	IO_Manual 		PCin(14)  		//IO �ֶ�
#define	IO_Auto 		PCin(13)  		//IO �ֶ�

#define	DIG1_Control 		PCout(0)  		//��һ��LED������
#define	DIG2_Control 		PCout(1)  		//�ڶ���LED������
#define	DIG3_Control 		PCout(2)  		//������LED������
#define	DS_a 		PAout(0)  		//pwmʹ���ź�  ����Ч
#define	DS_b 		PAout(1)  		//pwmʹ���ź�  ����Ч
#define	DS_c 		PAout(2)  		//pwmʹ���ź�  ����Ч
#define	DS_d 		PAout(3)  		//pwmʹ���ź�  ����Ч
#define	DS_e 		PAout(4)  		//pwmʹ���ź�  ����Ч
#define	DS_f 		PAout(5)  		//pwmʹ���ź�  ����Ч
#define	DS_g 		PAout(6)  		//pwmʹ���ź�  ����Ч
#define	DS_dp 		PAout(7)  		//pwmʹ���ź�  ����Ч

#define	DS_LE1		PBout(7)  		//pwmʹ���ź�  ����Ч
#define	DS_LE2 		PBout(6)  		//pwmʹ���ź�  ����Ч
#define	DS_LE3 		PBout(5)  		//pwmʹ���ź�  ����Ч
#define	DS_LE4 		PCout(4)  		//pwmʹ���ź�  ����Ч
#define	DS_LE5 		PCout(5)  		//pwmʹ���ź�  ����Ч
#define	DS_LE6 		PBout(0)  		//pwmʹ���ź�  ����Ч
#define	DS_LE7 		PBout(1)  		//pwmʹ���ź�  ����Ч
#define	DS_LE8 		PBout(10)  		//pwmʹ���ź�  ����Ч
#define	DS_LE9 		PBout(11)  		//pwmʹ���ź�  ����Ч
#define	DS_LE10 		PDout(2)  	//pwmʹ���ź�  ����Ч

#define Sel_1S_1  PBout(15)  		//ѡ�����  ����Ч
#define Sel_1S_2  PCout(6)  		//ѡ�����  ����Ч
#define Sel_1S_3  PCout(7)  		//ѡ�����  ����Ч
#define Sel_2S_1  PBout(12)  		//ѡ�����  ����Ч
#define Sel_2S_2  PBout(13)  		//ѡ�����  ����Ч
#define Sel_2S_3  PBout(14)  		//ѡ�����  ����Ч

#define SelIN_1S_1  PAin(8)  		//ѡ������  ����Ч
#define SelIN_1S_2  PAin(9)  		//ѡ������  ����Ч
#define SelIN_2S_1  PCin(8)  		//ѡ������  ����Ч
#define SelIN_2S_2  PCin(9)  		//ѡ������  ����Ч

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
typedef struct
{
  float SPD_KP;//����ٶȻ�����
	float SPD_KI;
	float SPD_VI;	
	float IA;//��������
	float IB;
	float IC;
	float IA_Zero;//������λ
	float IB_Zero;
	float IC_Zero;
	float P_Zero;
	float Pos;	//ת��λ��
	float Speed_Ref;//�ٶ�ָ��
	float Speed_RefS;//�ٶ�ָ�����
	float Speed;        // ���ʵ��ת��(RPM)
  uint16_t Direction;    // ���ת������ 0Ϊ˳ʱ�룬1Ϊ��ʱ��

}MOTOR_DEVICE;//�������
MOTOR_DEVICE MOTOR={0.01,0.0001,0,0,0,0,0,0,0,0,0,0,0,0,1};
typedef struct
{
  float Tem;//�¶�
	float CommandA;//ģ��ָ��
	float Command_RX;	//ͨѶָ��
	uint16_t RunFlag ;  
	uint16_t Zero_C ; 
	uint16_t Start_C ; 
	uint16_t Protect_FLAG;
}SYS_DEVICE;//ϵͳ����
SYS_DEVICE SYS={0.0,0.0,0.0,0,0,0,0};
float CUR_Command = 0.0;
float PWM_Command = 0.0;
uint16_t Run_State =0; 
uint16_t Sys_timer =0; 
uint16_t Sys_timer2 =0; 
uint32_t Pos_BISS[18]= {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
uint32_t Pos_M  = 0;	uint32_t Pos_M_Pre = 0;
uint8_t DataRx_Num = 0;//ͨѶ�յ����ݳ���

CLARKE clarke1 = CLARKE_DEFAULTS;
PARK park1 = PARK_DEFAULTS;
IPARK ipark1 = IPARK_DEFAULTS;
PI_CONTROLLER pi_spd = PI_CONTROLLER_DEFAULTS;
PI_CONTROLLER pi_id  = PI_CONTROLLER_DEFAULTS;
PI_CONTROLLER pi_iq  = PI_CONTROLLER_DEFAULTS;
SVGEN svgen1 = SVGEN_DEFAULTS;
PWMGEN pwm1 = PWMGEN_DEFAULTS;
uint8_t i =0; 
uint8_t j =0; uint8_t m =0; uint8_t n =0; 
uint16_t Disp =0; 
uint16_t	Number[11]  ={0,1,2,3,4,5,6,7,8,9,10};
uint16_t	LED_Number =0;
uint16_t	Sel =0;
uint8_t	Power_Sel =0;
uint8_t	Spd_Sel =0;
uint8_t	Sys_Mode  = 0; 
uint16_t TIME_S = 0; 
uint16_t Distance_M = 0; 
uint16_t POWER_S = 0;
uint8_t Electrical_v = 0;
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CAN_HandleTypeDef hcan1;

TIM_HandleTypeDef htim1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM1_Init(void);
static void MX_CAN1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM1_Init();
  MX_CAN1_Init();
  /* USER CODE BEGIN 2 */

//	delay_init(144);
//	delay_ms(1000);
	LED = 1;	
	DIG1_Control =1 ;	DIG2_Control =1 ;	DIG3_Control =1 ;	
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		if(Run_State == 1)
		{			
			Run_State =0;
			LED = 1;				
//			if(Sys_timer % 10 == 0)	//1ms
//			{	
				if(IO_Manual == 1 )
				Sys_Mode = 1;	// 1Ϊ�ֶ� 2Ϊ�Զ�
				else
				Sys_Mode = 2;
				// ʱ�� �ߵ��� 123  ���� �ߵ��� 456 ���� 789
				Number[1] = TIME_S/ 100;  Number[2] = (TIME_S%100)/10;  Number[3] = TIME_S % 10; 
				Number[4] = Distance_M/100;  Number[5] = (Distance_M%100)/10;  Number[6] = Distance_M % 10; 
				Number[7] = POWER_S/1000; Number[8] = (POWER_S%1000)/100;  Number[9] = (POWER_S%100)/10; Number[10] = POWER_S % 10;
				switch(Electrical_v)
				{
					case 1: LED_L = 1; LED_H = 0;LED_M = 0;break;
					case 2: LED_M = 1; LED_L = 1;LED_H = 0; break;
					case 3: LED_H = 1; LED_L = 1; LED_M = 1;break;					
				}
				
				//�������ʾ
				for(i =1;i<11;i++)
				{	
					LED_Number = i;
					switch(LED_Number)
					{
					case 1: DS_LE1 = 1; break;
					case 2: DS_LE2 = 1; break;
					case 3: DS_LE3 = 1; break;
					case 4: DS_LE4 = 1; break;
					case 5: DS_LE5 = 1; break;
					case 6: DS_LE6 = 1; break;
					case 7: DS_LE7 = 1; break;
					case 8: DS_LE8 = 1; break;
					case 9: DS_LE9 = 1; break;	
					case 10: DS_LE10 = 1; break;						
					}	
					switch(Number[i])
					{
					case 0: Disp = DISP0; break;
					case 1: Disp = DISP1; break;
					case 2: Disp = DISP2; break;
					case 3: Disp = DISP3; break;
					case 4: Disp = DISP4; break;
					case 5: Disp = DISP5; break;
					case 6: Disp = DISP6; break;
					case 7: Disp = DISP7; break;
					case 8: Disp = DISP8; break;
					case 9: Disp = DISP9; break;
					}	
					for(j= 0;j<200;j++){;}
					DS_a = (Disp & 0x0080)>>7 ; //a
					DS_b = (Disp & 0x0040)>>6 ; //b
					DS_c = (Disp & 0x0020)>>5 ; //c
					DS_d = (Disp & 0x0010)>>4 ; //d
					DS_e = (Disp & 0x0008)>>3 ; //e
					DS_f = (Disp & 0x0004)>>2 ; //f
					DS_g = (Disp & 0x0002)>>1 ; //g
					DS_dp = (Disp & 0x0001)>>0 ; //DP
				
					DS_LE1 = 0;DS_LE2 = 0;DS_LE3 = 0;DS_LE4 = 0;DS_LE5 = 0;DS_LE6 = 0;DS_LE7 = 0;DS_LE8 = 0;DS_LE9 = 0;DS_LE10 = 0;
				}
				
				//����������
				for(i =0;i<5;i++)
				{	
					Sel = i;
					switch(Sel)
					{
					case 0: Sel_1S_1 = 0; Sel_1S_2 = 0; Sel_1S_3 = 0; Sel_2S_1 = 0; Sel_2S_2 = 0; Sel_2S_3 = 0; break;	
					case 1: Sel_1S_1 = 1; Sel_1S_2 = 0; Sel_1S_3 = 0; Sel_2S_1 = 1; Sel_2S_2 = 0; Sel_2S_3 = 0; break;
					case 2: Sel_1S_1 = 0; Sel_1S_2 = 1; Sel_1S_3 = 0; Sel_2S_1 = 0; Sel_2S_2 = 1; Sel_2S_3 = 0; break;
					case 3: Sel_1S_1 = 1; Sel_1S_2 = 1; Sel_1S_3 = 0; Sel_2S_1 = 1; Sel_2S_2 = 1; Sel_2S_3 = 0; break;
					case 4: Sel_1S_1 = 0; Sel_1S_2 = 0; Sel_1S_3 = 1; Sel_2S_1 = 0; Sel_2S_2 = 0; Sel_2S_3 = 1; break;
					}
					for(j= 0;j<200;j++){;}  //�л������ӳٵ�
					if(SelIN_1S_1 != 0)  //1S���ٶ� 2S������
					Spd_Sel	 = 9 - i;
					if(SelIN_2S_1 != 0)
					Power_Sel	 = 9- i;					
				}
				for(i =0;i<5;i++)
				{	
					Sel = i;
					switch(Sel)
					{
					case 0: Sel_1S_1 = 0; Sel_1S_2 = 0; Sel_1S_3 = 0; Sel_2S_1 = 0; Sel_2S_2 = 0; Sel_2S_3 = 0; break;	
					case 1: Sel_1S_1 = 1; Sel_1S_2 = 0; Sel_1S_3 = 0; Sel_2S_1 = 1; Sel_2S_2 = 0; Sel_2S_3 = 0; break;
					case 2: Sel_1S_1 = 0; Sel_1S_2 = 1; Sel_1S_3 = 0; Sel_2S_1 = 0; Sel_2S_2 = 1; Sel_2S_3 = 0; break;
					case 3: Sel_1S_1 = 1; Sel_1S_2 = 1; Sel_1S_3 = 0; Sel_2S_1 = 1; Sel_2S_2 = 1; Sel_2S_3 = 0; break;
					case 4: Sel_1S_1 = 0; Sel_1S_2 = 0; Sel_1S_3 = 1; Sel_2S_1 = 0; Sel_2S_2 = 0; Sel_2S_3 = 1; break;
					}
					
					for(j= 0;j<200;j++){;}
					test =   SelIN_2S_2;
					if(SelIN_1S_2 != 0)  
					Spd_Sel	 = 9- (i+5);
					if(SelIN_2S_2 != 0)
					Power_Sel	 = 9- (i+5);				
				}
//				if(Spd_Sel >=2) 
//				Spd_Sel = 2;	
				canbuf_Tx[0] = Power_Sel;	
				canbuf_Tx[1] = Spd_Sel;	
				canbuf_Tx[2] = Sys_Mode;
					canbuf_Tx[5] =  0xAA;
				canbuf_Tx[6] =  0xBB;
			if(Sys_timer % 100 == 0)	//1ms
			{			
				CAN1_Send_Msg(canbuf_Tx,8);		
				Ref_Get();	
				Sys_timer =0;	
			}	
			if(Sys_timer2 % 150 == 0)	//1ms
			{			
//				CAN1_Send_Msg(canbuf_Tx,8);		
//				Ref_Get();	
				Sys_timer2 =50;	
			}				
//				Sys_timer =0;					
//			}

			LED = 0;			
		}
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 144;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CAN1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_CAN1_Init(void)
{

  /* USER CODE BEGIN CAN1_Init 0 */

  /* USER CODE END CAN1_Init 0 */

  /* USER CODE BEGIN CAN1_Init 1 */

  /* USER CODE END CAN1_Init 1 */
  hcan1.Instance = CAN1;
  hcan1.Init.Prescaler = 12;
  hcan1.Init.Mode = CAN_MODE_NORMAL;
  hcan1.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan1.Init.TimeSeg1 = CAN_BS1_3TQ;
  hcan1.Init.TimeSeg2 = CAN_BS2_2TQ;
  hcan1.Init.TimeTriggeredMode = DISABLE;
  hcan1.Init.AutoBusOff = DISABLE;
  hcan1.Init.AutoWakeUp = DISABLE;
  hcan1.Init.AutoRetransmission = DISABLE;
  hcan1.Init.ReceiveFifoLocked = DISABLE;
  hcan1.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN1_Init 2 */
		sFilterConfig.FilterBank = 0;									// ʹ�ù�����0
		sFilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;				// ����λģʽ
		sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;				// 32λ��
	  sFilterConfig.FilterIdHigh = 0x0A51<<3;								// ID��ʮ��λ
		sFilterConfig.FilterIdLow = 0x0201<<3;								// ID��ʮ��λ
		sFilterConfig.FilterMaskIdHigh =0x0000;						// ID�����ʮ��λ
		sFilterConfig.FilterMaskIdLow = 0x0000;							// ID�����ʮ��λ
		sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO0;				// ������0������FIFO0
		sFilterConfig.FilterActivation = ENABLE;						// **������0
		sFilterConfig.SlaveStartFilterBank = 14;
	if (HAL_CAN_ConfigFilter(&hcan1, &sFilterConfig) != HAL_OK)
	{
		Error_Handler();
	}

	if (HAL_CAN_Start(&hcan1) != HAL_OK)
	{
		Error_Handler();
	}

	if (HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING | CAN_IT_RX_FIFO0_FULL) != HAL_OK)		// ʹ��FIFO0�����жϽ���
	{
		Error_Handler();
	}
//	HAL_CAN_Receive_IT(&hcan, CAN_FIFO0);
	//	TxHeader.ExtId = 0x0A510102;//���� ID��
  TxHeader.RTR = CAN_RTR_DATA;
  TxHeader.IDE = CAN_ID_EXT;
  TxHeader.DLC = 8;
  /* USER CODE END CAN1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 9;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 14399;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */
  HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_3);
	HAL_TIMEx_PWMN_Start(&htim1,TIM_CHANNEL_1);
	HAL_TIMEx_PWMN_Start(&htim1,TIM_CHANNEL_2);
	HAL_TIMEx_PWMN_Start(&htim1,TIM_CHANNEL_3);
	HAL_TIM_IC_Start_IT(&htim1,TIM_CHANNEL_1);
	__HAL_TIM_ENABLE_IT(&htim1,TIM_IT_UPDATE); //ʹ�ܸ����ж�
	HAL_NVIC_SetPriority(TIM3_IRQn,1,2);//�����ж����ȼ���
  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15|GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7
                          |GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_10|GPIO_PIN_11
                          |GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_RESET);

  /*Configure GPIO pins : PC13 PC14 PC8 PC9 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PC15 PC0 PC1 PC2
                           PC4 PC5 PC6 PC7 */
  GPIO_InitStruct.Pin = GPIO_PIN_15|GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA0 PA1 PA2 PA3
                           PA4 PA5 PA6 PA7
                           PA10 PA11 PA12 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7
                          |GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB10 PB11
                           PB12 PB13 PB14 PB15
                           PB5 PB6 PB7 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_10|GPIO_PIN_11
                          |GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PA8 PA9 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PD2 */
  GPIO_InitStruct.Pin = GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */


void Protect(void)
{
	if( SYS.Tem > 2500 )  Flag.Status.OverTem = 1; else Flag.Status.OverTem = 0; //��������£�70������
	if((fabs(MOTOR.IA) > 20.0)|(fabs(MOTOR.IB) > 20.0)|(fabs(MOTOR.IC) > 20.0)) Flag.Status.CurOver =1; else Flag.Status.CurOver =0;//����
	if(Flag.Stop != 0) 
	{		
		HAL_TIM_PWM_Stop(&htim1,TIM_CHANNEL_1);
		HAL_TIM_PWM_Stop(&htim1,TIM_CHANNEL_2);
		HAL_TIM_PWM_Stop(&htim1,TIM_CHANNEL_3);
		HAL_TIMEx_PWMN_Stop(&htim1,TIM_CHANNEL_1);
		HAL_TIMEx_PWMN_Stop(&htim1,TIM_CHANNEL_2);
		HAL_TIMEx_PWMN_Stop(&htim1,TIM_CHANNEL_3);
		pi_iq.Ki =0.0;pi_id.Ki =0.0;
		pi_iq.i1 =0 ;pi_iq.ui = 0;pi_iq.v1 =0;
		pi_id.i1 =0 ;pi_id.ui = 0;pi_id.v1 =0;
		SYS.Protect_FLAG		 =0;
	}
	else
	{
		if(SYS.Protect_FLAG == 0 )
		{	
		SYS.Protect_FLAG 	 ++;
		HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);
		HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_2);
		HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_3);
		HAL_TIMEx_PWMN_Start(&htim1,TIM_CHANNEL_1);
		HAL_TIMEx_PWMN_Start(&htim1,TIM_CHANNEL_2);
		HAL_TIMEx_PWMN_Start(&htim1,TIM_CHANNEL_3);
		pi_iq.Ki =0.065;pi_id.Ki =0.065;
		}
	}	
}
void Ref_Get(void)
{
	DataRx_Num = CAN1_Receive_Msg(canbuf);
	if(DataRx_Num == 8)
	{
		TIME_S = canbuf[0];
		Distance_M = canbuf[1];
		POWER_S =  canbuf[2] * 256 +canbuf[3];
		Electrical_v =  canbuf[4];	
		if(Electrical_v	>3)
			Electrical_v = 3;
//		canbuf_Rx[0] =canbuf[0];canbuf_Rx[1] =canbuf[1];
//		MOTOR.Speed_Ref  =  (short)((canbuf_Rx[0] <<8) +  canbuf_Rx[1]); //
	}
}
void SpdLoop(void)
{
//	MOTOR.Speed = ( ECounter - ECounter_Pre ) * 500.0 * 60.0 /2048.0;//ת/����
//	ECounter_Pre = ECounter;
	if(MOTOR.Speed_Ref > 1000) MOTOR.Speed_Ref = 1000;
	if(-1000 > MOTOR.Speed_Ref)  MOTOR.Speed_Ref = -1000;
	pi_spd.Ref =  MOTOR.Speed_Ref /SPD_PU;
	pi_spd.Fbk = MOTOR.Speed /SPD_PU;
	PI_MACRO(pi_spd);
}
uint8_t CAN1_Receive_Msg(uint8_t *buf)
{
 	uint8_t i;
	uint8_t	RxData[8];
//	HAL_CAN_ActivateNotification(&hcan, CAN_IT_RX_FIFO0_MSG_PENDING);	// �ٴ�ʹ��FIFO0�����ж�
//	if(HAL_CAN_GetRxFifoFillLevel(&hcan, CAN_RX_FIFO0) != 1)
	if(HAL_CAN_GetRxFifoFillLevel(&hcan1, CAN_RX_FIFO0) == 0)
	{
		return 0xF1;
	}

	if(HAL_CAN_GetRxMessage(&hcan1, CAN_RX_FIFO0, &RxHeader, RxData) != HAL_OK)
	{
		return 0xF2;
	}
    for(i=0;i<RxHeader.DLC;i++)
    buf[i]=RxData[i];
		
	return RxHeader.DLC;
}
uint8_t CAN1_Send_Msg(uint8_t* msg,uint8_t len)
{	
    uint8_t i=0;
		uint32_t TxMailbox;
		uint8_t message[8];//�������ݷ���
              
    for(i=0;i<len;i++)
    {
		message[i]=msg[i];
		}
		message[4] = 0 ; message[5] = 0 ; message[6] = 0 ;message[7] = 0 ;
    if(HAL_CAN_AddTxMessage(&hcan1, &TxHeader, message, &TxMailbox) != HAL_OK)//����
		{
			return 1;
		}
//		while(HAL_CAN_GetTxMailboxesFreeLevel(&hcan1) != 3) {}
//    return 0;
}
void PwmGen(void)
{	
		  pwm1.MfuncC1 = svgen1.Ta;
		  pwm1.MfuncC2 = svgen1.Tb;
		  pwm1.MfuncC3 = svgen1.Tc;
      if( pwm1.MfuncC1 > 0.92) pwm1.MfuncC1= 0.92;
      if( pwm1.MfuncC1 < -0.92) pwm1.MfuncC1= -0.92;
      if( pwm1.MfuncC2 > 0.92) pwm1.MfuncC2= 0.92;
      if( pwm1.MfuncC2 < -0.92) pwm1.MfuncC2= -0.92;
      if( pwm1.MfuncC3 > 0.92) pwm1.MfuncC3= 0.92;
      if( pwm1.MfuncC3 < -0.92) pwm1.MfuncC3= -0.92;	
//			pwm1.DutyA = 	pwm1.MfuncC1 * 3600 + 3600;
//			pwm1.DutyB = 	pwm1.MfuncC2 * 3600 + 3600;
//			pwm1.DutyC = 	pwm1.MfuncC3 * 3600 + 3600;
			pwm1.DutyA = 3600;
			pwm1.DutyB = 3600;
			pwm1.DutyC = 3600;
			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, pwm1.DutyA); 
			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, pwm1.DutyB); 
			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, pwm1.DutyC);		
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
